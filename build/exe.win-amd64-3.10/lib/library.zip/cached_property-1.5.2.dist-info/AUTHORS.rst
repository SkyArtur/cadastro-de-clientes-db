=======
Credits
=======

Development Lead
----------------

* Daniel Roy Greenfeld (@pydanny)
* Audrey Roy Greenfeld (@audreyr)

Contributors
------------

* Tin Tvrtković <tinchester@gmail.com>
* @bcho <bcho@vtmer.com>
* George Sakkis (@gsakkis)
* Adam Williamson <awilliam AT redhat DOT com>
* Ionel Cristian Mărieș (@ionelmc)
* Malyshev Artem (@proofit404)
* Volker Braun (@vbraun)
* Qudus Oladipo (@stikks)
